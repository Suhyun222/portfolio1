import React from 'react'

function NotFound() {
  return (
    <div>
      경로가 틀렸습니다.
    </div>
  )
}

export default NotFound
