/*eslint-disable*/ 
export default function initScripts(){
    $(function () {
         
      // Typed 라이브러리 사용(실행)
      var typed = new Typed("#typed-words", {
        strings: [
            "I want to introduce",
            
          "my favorite things",

         
        ],
        typeSpeed: 80,
        backSpeed: 80,
        
      
        loop: true,
        showCursor: true,
        cursorChar: "_"
       
      });
      
      })

      // 1 ,2
      $(document).ready(function() {
        $('.show1').show(); //페이지를 로드할 때 표시할 요소
        $('.show2').hide(); //페이지를 로드할 때 숨길 요소
        $('.show1').click(function(){
        $ ('.show1').hide(); //클릭 시 첫 번째 요소 숨김
        $ ('.show2').show(); //클릭 시 두 번째 요소 표시
        return false;
        });
        });

        // 3, 4
        $(document).ready(function() {
          $('.show3').show(); //페이지를 로드할 때 표시할 요소
          $('.show4').hide(); //페이지를 로드할 때 숨길 요소
          $('.show3').click(function(){
          $ ('.show3').hide(); //클릭 시 첫 번째 요소 숨김
          $ ('.show4').show(); //클릭 시 두 번째 요소 표시
          return false;
          });
          });

           // 5,6
        $(document).ready(function() {
          $('.show5').show(); //페이지를 로드할 때 표시할 요소
          $('.show6').hide(); //페이지를 로드할 때 숨길 요소
          $('.show5').click(function(){
          $ ('.show5').hide(); //클릭 시 첫 번째 요소 숨김
          $ ('.show6').show(); //클릭 시 두 번째 요소 표시
          return false;
          });
          });
    
    }