import React, { useState, useEffect } from "react";

// 통신 라이브러리 함수
import LifeDataService from "../services/LifeDataService";

// 페이지 라이브러리 import
import Pagination from "@material-ui/lab/Pagination";

// 테마 개발자용 css import
import "../assets/css/meyawo.css";

// 테마 개발자용 js import
import meyawo from "../assets/js/meyawo.js";

// Typed js
import initScripts from "../assets/js/typed";

/* eslint-disable */ 
function Home() {

   // 변수 정의
  // 벡엔드에서 전송한 Life객체배열을 저장할 변수
  const [life, setLife] = useState([]);
  // 현재 클릭한 Life객체를 저장할 변수
  const [currentLife, setCurrentLife] = useState(null);
  // 현재 클릭한 Life배열의 인덱스번호를 저장할 변수
  const [currentIndex, setCurrentIndex] = useState(-1);
  // 검색어를 저장할 변수
  const [searchLifeSentence, setSearchLifeSentence] = useState("");

  // TODO: page : 현재 페이지 번호를 저장할 변수
  // TODO: 벡엔드에서 전송한 현재 페이지 번호
  const [page, setPage] = useState(1);
  // TODO: 벡엔드에서 전송한 총 페이지 개수를 저장할 변수
  const [count, setCount] = useState(0);
  // TODO: 셀렉트 박스에서 기본으로 사용할 변수 : 1
  const [pageSize, setPageSize] = useState(1);

  // TODO: 셀렉트 박스의 내용 : 3, 6, 9 목록이 있음(배열변수)
  const pageSizes = [1, 2, 3];


  // 함수 정의
  // 수동 바인딩 : 화면입력값 변경 -> 변수도 변경 코딩
  // onchange 함수 : Life명 검색
  const onChangeSearchLifeSentence = (e) => {
    const searchLifeSentence = e.target.value; // 화면 입력값
    setSearchLifeSentence(searchLifeSentence); // 변수에 저장
  };

  // 전체 조회 함수
  const retrieveLife = () => {
 
    // 콘솔로그 : searchLifeSentence, page-1, pageSize 출력
    console.log("retrieveLife", searchLifeSentence, page - 1, pageSize);
  
    // 벡엔드 전체조회요청 함수
    // searchLifeSentence : Life명검색어(화면입력값)
    // page : 현재페이지
    // pageSize : 현재 페이지당 개수
    LifeDataService.getLifeAll(searchLifeSentence, page - 1, pageSize)
      .then((response) => {
  
        // 성공 : response.data(벡엔드에서 전송한 데이터)
        // 벡엔드)
        //  map 자료구조로 전송됨
        //  (life, 현재페이지번호, 총건수, 총페이지개수)
        // 구조 분해 할당
        // const life = response.data.life;
        // const totalPages = response.data.totalPages;
        const { life, totalPages } = response.data;

        setLife(life); // Life배열객체 저장
        setCount(totalPages); // 총페이지 개수 저장
        // 벡엔드 전송된 데이터를 콘솔 출력
        console.log(response.data);

      })
      .catch((e) => {
        // 실패
        console.log(e);
      });
  };


  // 화면이 뜨자마자 실행되는 이벤트 함수
  useEffect(() => {
    // 테마 js 파일 실행
    
    meyawo();
    initScripts();
    
  }, []);
  // 전체조회를 실행함(retrieveLife())
  // page, pageSize 의 값이 변하면 다시 재실행(retrieveLife())
  
  useEffect(retrieveLife, [page, pageSize]);

   // Material UI 에서 제공하는 페이지 컨트롤이 변경되었을때
  // 현재 페이지번호를 변경했을때 : 1 -> 2 등
  const handlePageChange = (event, value) => {
    setPage(value); // 변경된 현재페이지 번호를 저장
  };

  // 셀렉트박스의 목록의 값을 변경시 실행하는 함수
  // onchange 함수 : 1,2,3
  const handlePageSizeChange = (event) => {
    setPageSize(event.target.value); // 화면의 입력값
    setPage(1);   // 현재페이지 1로 고정 저장
  };



  
  return (
    <div>
      {/* 모달 시작 */}
      <div>
      {/* 모달 1 시작 */}
      <div
        class="modal fade"
        id="firstModal"
        tabindex="-1"
        aria-labelledby="firsteModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content">
            <div class="modal-header">
            <div class="modal-title" id="secondModalLabel">
                <h5>우리는 사랑아니면 여행이겠지</h5>
              </div>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
            <span>
              "만남은 서로의 책임이야 <br></br>
              뭐든 지나치게 미안해 할 필요는 없어"
                </span>
            </div>
            <div class="modal-footer  " >
           <div className="container">
          
          <div class="show1">
           <button type="button" class="btn btn-primary" id="popBox">
              I love it!
              </button>
              </div>

              <div class="show2">
              <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;    
              </div>

            </div>             
            </div>
          </div>
        </div>
      </div>
      {/* 모달 1 끝 */}
      {/* 모달 2 시작 */}      
      <div
        class="modal fade"
        id="secondModal"
        tabindex="-1"
        aria-labelledby="secondModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content">
            <div class="modal-header">
              <div class="modal-title" id="secondModalLabel">
                <h5>자존감의 여섯 기둥</h5>
              </div>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
              <span>
              "힘들지만 필요한 무언가를 하는 것이 <br></br>
              꼭 '대단한 일'일 필요는 없다"
                </span>
            </div>
            <div class="modal-footer">
            <div className="container">
            <div class="show3">
           <button type="button" class="btn btn-primary" id="popBox">
              I love it!
              </button>
              </div>

              <div class="show4">
              <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;    
              </div>

            </div>
            </div>

          </div>
        </div>
      </div>
      {/* 모달 2 끝 */}
       {/* 모달 3 시작 */}      
       <div
        class="modal fade"
        id="thirdModal"
        tabindex="-1"
        aria-labelledby="thirdModalLabel"
        aria-hidden="true"
      >
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
          <div class="modal-content">
            <div class="modal-header">
              <div class="modal-title" id="thirdModalLabel">
                <h5>클루지</h5>
                
              </div>
              <button
                type="button"
                class="btn-close"
                data-bs-dismiss="modal"
                aria-label="Close"
              ></button>
            </div>
            <div class="modal-body">
             <span> "개인의 수준에서 기회비용을 고려한다는 것은 <br></br>
              우리가 무엇을 하기로 결정할 때마다,<br></br>
               이것 아니면 다르게 보낼 시간(돈)을
              사용하고 있음을 깨닫는 것을 의미한다."
              </span>
            </div>
            <div class="modal-footer">
             
            <div className="container">
            <div class="show5">
           <button type="button" class="btn btn-primary" id="popBox">
              I love it!
              </button>
              </div>

              <div class="show6">
              <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;
            <img className="popImg" src={require("../assets/imgs/down/openHeart.svg").default} />
            &nbsp;    
              </div>              
            </div>     
            </div>
          </div>
        </div>
      </div>
      {/* 모달 3 끝 */}
      </div>
      {/* 모달 끝 */}
      <div data-spy="scroll" data-target=".navbar" data-offset="40" id="home">
        {/* <!-- Page Navbar --> */}
        <nav class="custom-navbar" data-spy="affix" data-offset-top="20">
          <div class="container">
            {/* 상단 좌측 로고 */}
            <a class="logo" href="#">
              HaHa
            </a>

            {/* 메뉴 시작 */}
            <ul class="nav">
              <li class="item">
                <a class="link" href="#home">
                  Home
                </a>
              </li>
              <li class="item">
                <a class="link" href="#about">
                  About
                </a>
              </li>
              <li class="item">
                <a class="link" href="#portfolio">
                  Place
                </a>
              </li>
              <li class="item">
                <a class="link" href="#testmonial">
                  Sentence
                </a>
              </li>
              <li class="item">
                <a class="link" href="#blog">
                  Trip
                </a>
              </li>
              <li class="item">
                <a class="link" href="#contact">
                  Contact
                </a>
              </li>
              <li class="item ml-md-3">
                <a href="components.html" class="btn btn-primary">
                  Components
                </a>
              </li>
            </ul>
            {/* 메뉴 끝 */}

            <a
              href="javascript:void(0)"
              id="nav-toggle"
              class="hamburger hamburger--elastic"
            >
              <div class="hamburger-box">
                <div class="hamburger-inner"></div>
              </div>
            </a>
          </div>
        </nav>
        {/* <!-- End of Page Navbar --> */}

        {/* <!-- 메인화면 시작 --> */}
        <header id="home" class="header">
          <div class="overlay"></div>
          <div class="header-content container">
            <h1 class="header-title">
              <span class="up">HI!</span>
              <span class="down">I am SuHyun</span>
            </h1>
            <span class="header-subtitle" id="typed-words" ></span>
               <br></br>       
               
            <button class="btn btn-primary">
            <i className='bi bi-heart'> </i>
            <i className='bi bi-heart-fill'> </i>
            <i className='bi bi-heart'> </i>
            <i className='bi bi-heart-fill'> </i>
            <i className='bi bi-heart'></i>

            </button>
          </div>
        </header>
        {/* <!-- 메인화면 끝 --> */}

        {/* <!-- about me 시작 --> */}
        <section class="section pt-0" id="about">
          {/* <!-- container --> */}
          <div class="container text-center">
            {/* <!-- about wrapper --> */}
            <div class="about">
              <div class="about-img-holder">
                <img
                  src={require("../assets/imgs/down/me.jpg")}
                  class="about-img"
                  alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                />
              </div>
              <div class="about-caption">
                <p class="section-subtitle">Who Am I ?</p>
                <h2 class="section-title mb-3">About Me</h2>
                
                <p >
                  <img className="aboutme" src={require("../assets/imgs/down/smile.png")}/> 
                  &nbsp;&nbsp;
                  <img className="aboutme" src={require("../assets/imgs/down/burger.png")}/>
                  &nbsp;&nbsp; 
                  <img className="aboutme" src={require("../assets/imgs/down/camera1.png")}/> 
                  &nbsp;&nbsp;
                  <img className="aboutme" src={require("../assets/imgs/down/family.png")}/>
                  <br/> <br/>
                  <span className="textme">먹고 사진찍고 여행가는게 좋아</span> 
                             
                
                </p>
                <a class="link" href="#service">
                <button class="btn-rounded btn btn-outline-primary mt-4">
                Scroll down!!
                </button>
                </a>

                
              </div>
            </div>
            {/* <!-- end of about wrapper --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- about me 끝 --> */}

        {/* <!-- Interest 시작 --> */}
        <section class="section" id="service">
          <div class="container text-center">
            <p class="section-subtitle">What I Like ?</p>
            <h6 class="section-title mb-6">Interest</h6>
            {/* <!-- row --> */}
            <div class="row">
              <div class="col-md-6 col-lg-3">
                <div class="service-card">
                  {/* 1번째 아이콘 시작 */}
                  <div class="body">
                    <img
                      src={require("../assets/imgs/down/trip.png")}
                      alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                      class="icon"
                    />
                    {/* 아이콘 이름 */}
                    <h6 class="title">TRIP</h6>
                    {/* 아이콘 설명 */}
                    <p class="subtitle" id="interest1">
                    It's good to travel in Korea or abroad. And I prefer to travel leisurely rather than carrying out a busy schedule
                    </p>
                  </div>
                  {/* 1번째 아이콘 끝 */}
                </div>
              </div>
              <div class="col-md-6 col-lg-3">
                <div class="service-card">
                  {/* 2번째 아이콘 시작 */}
                  <div class="body">
                    <img
                      src={require("../assets/imgs/down/movie.png")}
                      alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                      class="icon"
                    />
                    {/* 아이콘 이름 */}
                    <h6 class="title">MOVIE</h6>
                    {/* 아이콘 설명 */}
                    <p class="subtitle" id="interest2">
                    I like romantic comedies and SF genres, especially action. 
                    When I watch a movie at home, I like watching it with my friends
                    </p>
                  </div>
                  {/* 2번째 아이콘 끝 */}
                </div>
              </div>
              <div class="col-md-6 col-lg-3">
                <div class="service-card">
                  {/* 3번째 아이콘 시작 */}
                  <div class="body">
                    <img
                      src={require("../assets/imgs/down/art.png")}
                      alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                      class="icon"
                    />
                    {/* 아이콘 이름 */}
                    <h6 class="title">ART</h6>
                    {/* 아이콘 설명 */}
                    <p class="subtitle" id="interest3">
                    I also like painting oil paintings, coloring, and making things.
                    These days, it's good to draw using an iPad app
                    </p>
                  </div>
                  {/* 3번째 아이콘 끝 */}
                </div>
              </div>
              <div class="col-md-6 col-lg-3">
                <div class="service-card">
                  {/* 4번째 아이콘 시작 */}
                  <div class="body">
                    <img
                      src={require("../assets/imgs/down/gamepad_wh.png")}
                      alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                      class="icon"
                    />
                    {/* 아이콘 이름 */}
                    <h6 class="title">GAME</h6>
                    {/* 아이콘 설명 */}
                    <p class="subtitle" id="interest4">
                    I like mobile games and computer games, but these days, I am focusing on computer games
                    </p>
                  </div>
                  {/* 4번째 아이콘 끝 */}
                </div>
              </div>
            </div>
            {/* <!-- end of row --> */}
          </div>
        </section>
        {/* <!-- Interest 끝 --> */}

        {/* <!-- 장소 시작 --> */}
        <section class="section" id="portfolio">
          <div class="container text-center">
            <p class="section-subtitle">What I Like ?</p>
            <h6 class="section-title mb-6">Place</h6>
            {/* <!-- row --> */}
            <div class="row">
              {/* 1번째 사진 시작 */}
              <div class="col-md-4">
                <a href="#" class="portfolio-card">
                  <img
                    src={require("../assets/imgs/river.jpg")}
                    class="portfolio-card-img img-responsive rounded"
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                  <span class="portfolio-card-overlay">
                    <span class="portfolio-card-caption">
                      <h4>단양강</h4>
                      <p class="font-weight-normal">2023.04.30</p>
                    </span>
                  </span>
                </a>
              </div>
              {/* 1번째 사진 끝 */}

              {/* 2번째 사진 시작 */}
              <div class="col-md-4">
                <a href="#" class="portfolio-card">
                  <img
                    class="portfolio-card-img img-responsive rounded"
                    src={require("../assets/imgs/flower.jpg")}
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                  <span class="portfolio-card-overlay">
                    <span class="portfolio-card-caption">
                      <h4>구례 대나무숲길</h4>
                      <p class="font-weight-normal">2022.04.16</p>
                    </span>
                  </span>
                </a>
              </div>
              {/* 2번째 사진 끝 */}

              {/* 3번째 사진 시작 */}
              <div class="col-md-4">
                <a href="#" class="portfolio-card">
                  <img
                    class="portfolio-card-img"
                    src={require("../assets/imgs/sea.jpg")}
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                  <span class="portfolio-card-overlay">
                    <span class="portfolio-card-caption">
                      <h4>제주도 형제섬</h4>
                      <p class="font-weight-normal">2022.10.05</p>
                    </span>
                  </span>
                </a>
              </div>
              {/* 3번째 사진 끝 */}
            </div>
            {/* <!-- end of row --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- 장소 끝 --> */}

        {/* <!-- 책 시작 --> */}
        <section class="section" id="pricing">
          <div class="container text-center">
            <p class="section-subtitle">What I Read ?</p>
            <h6 class="section-title mb-6">Book</h6>
            {/* <!-- row --> */}
            <div class="pricing-wrapper">
              {/* 첫번째 박스 시작 */}
              <div class="pricing-card">
                <div class="pricing-card-header">
                  <img
                    class="pricing-card-icon"
                    src={require("../assets/imgs/down/book1.jpg")}
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                </div>
                <div class="pricing-card-body">
                  <h6 class="pricing-card-title">우리는 사랑아니면 여행이겠지</h6>
                  <div class="pricing-card-list">
                    <p>최갑수의 여행하는 문장들</p>
                    <p>당신과 문장 사이를 여행할 때</p>
                    <p>저자 최갑수</p>
                    <p>출판 위즈덤하우스</p>
                    <p>
                      <i class="ti-close"></i>
                    </p>
                    <p>
                      <i class="ti-close"></i>
                    </p>
                  </div>
                </div>
                <div class="pricing-card-footer">
                  <span></span>
                  <span>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  </span>
                </div>

                {/* 버튼 1 시작 */}
                <button class="btn btn-primary mt-3 pricing-card-btn" data-bs-toggle="modal" data-bs-target="#firstModal">
                  Review
                </button>
                {/* 버튼 1 끝 */}
              </div>
              {/* 첫번째 박스 끝 */}

              {/* 두번째 박스 시작 */}
              <div class="pricing-card">
                <div class="pricing-card-header">
                  <img
                    class="pricing-card-icon"
                    src={require("../assets/imgs/down/book2.jpg")}
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                </div>
                <div class="pricing-card-body">
                  <h6 class="pricing-card-title">자존감의 여섯 기둥</h6>
                  <div class="pricing-card-list">
                    <p>어떻게 나를 사랑할 것인가</p>
                    <p>저자 너새니얼 브랜든</p>
                    <p>번역 김세진</p>
                    <p>출판 교양인</p>
                    
                    <p>
                      <i class="ti-close"></i>
                    </p>
                  </div>
                </div>
                <div class="pricing-card-footer">
                  
                  <span>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  </span>
                </div>
                 {/* 버튼 2 시작 */}
                 <button class="btn btn-primary mt-3 pricing-card-btn" data-bs-toggle="modal" data-bs-target="#secondModal">
                  Review
                </button>
                {/* 버튼 2 끝 */}
              </div>
              {/* 두번째 박스 끝 */}

              {/* 세번째 박스 시작 */}
              <div class="pricing-card">
                <div class="pricing-card-header">
                  <img
                    class="pricing-card-icon"
                    src={require("../assets/imgs/down/book3.jpg")}
                    alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                  />
                </div>
                <div class="pricing-card-body">
                  <h6 class="pricing-card-title">클루지</h6>
                  <div class="pricing-card-list">
                    <p>생각의 역사를 뒤집는 기막힌 발견</p>
                    <p>저자 개리 마커스</p>
                    <p>번역 최호영</p>
                    <p>출판 갤리온</p>
                   
                  </div>
                </div>
                <div class="pricing-card-footer">
                 
                  <span>
                  <i class="bi bi-star-fill"></i>
                  <i class="bi bi-star-fill"></i>
                  </span>
                </div>
                 {/* 버튼 3 시작 */}
                 <button class="btn btn-primary mt-3 pricing-card-btn" data-bs-toggle="modal" data-bs-target="#thirdModal">
                  Review
                </button>
                {/* 버튼 3 끝 */}
              </div>
              {/* 세번째 박스 끝 */}
            </div>
            {/* <!-- end of pricing wrapper --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- 책 끝 --> */}

        {/* <!-- 보라색 띠 부분 시작 --> */}
        <section class="section-sm bg-primary">
          {/* <!-- container --> */}
          <div class="container text-center text-sm-left">
            {/* <!-- row --> */}
            <div class="row align-items-center">
              <div class="col-sm offset-md-1 mb-4 mb-md-0">
                <h6 class="title text-light">Do you like this page?</h6>
                <p class="m-0 text-light" id="miniPurple">
                 I hope you like this
                </p>
              </div>
              <div class="col-sm offset-sm-2 offset-md-3">
            
                 <i class="bi bi-bookmark-heart" id="bookMark"></i>
               
              </div>
            </div>
            {/* <!-- end of row --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- 보라색 띠 부분 끝 --> */}

     {/* <!-- 문장 시작 --> */}
      <section class="section" id="testmonial">
        <div class="container text-center">
          <p class="section-subtitle">What I Read ?</p>
          <h6 class="section-title mb-6">Sentence</h6>

          {/* <!-- row --> */}
          <div class="row">
            {/* Life 콘텐츠 시작 */}
            <div class="col-md-12" >
              <div > 
                <div class="testimonial-card-body">
                   {/* 검색어 시작 */}
      <div className="searchBox">
         {/* 제목 */}
         <h4>Life & Love</h4>   
        <div className="input-group mb-3">
          {/* 검색어 입력양식 시작 */}
          <input 
            type="text"
            className="form-control"
            placeholder="Search by Sentence"
            value={searchLifeSentence}
            onChange={onChangeSearchLifeSentence}
          />
          {/* 검색어 입력양식 끝 */}

          {/* 검색 버튼 시작 */}
          <div className="input-group-append">
            <button
              className="btn btn-outline-secondary"
              type="button"
              onClick={retrieveLife}
            >
              Search
            </button>
          </div>
          {/* 검색 버튼 끝 */}
        </div>
      </div>
      {/* 검색어 끝 */}

      {/* 전체 목록 부분 + page 컨트롤추가 시작 */}
      <div className="lifeBox">
           

        {/* 전체 목록(반복문) 시작 */}
        <ul className="list-group" id="sentence1">
          {life &&
            life.map((life, index) => (
              <li
                className={
                  "list-group-item " + (index === currentIndex ? "active" : "")
                }
              >
                {life.lifeSentence} <br></br>
                - {life.lifeWriter} -
              </li>
            ))}
        </ul>
        {/* 전체 목록 끝 */}

         {/* 페이징 시작 */}
         <div className="mt-3">
          {/* 셀렉트박스(size:3,6,9) 시작 */}
          {"Items per Page: "}
          <select onChange={handlePageSizeChange} value={pageSize}>
            {pageSizes.map((size) => (
              <option key={size} value={size}>
                {size}
              </option>
            ))}
          </select>
          {/* 셀렉트박스(3,6,9) 끝 */}

          {/* Material UI 페이지 컨트롤 시작 */}
          <Pagination
            className="my-3"
          count={count}
            page={page}
            siblingCount={1}
            boundaryCount={1}
            variant="outlined"
            shape="rounded"
            onChange={handlePageChange}
          />
          {/* Material UI 페이지 컨트롤 끝 */}
        </div>
        {/* 페이징 끝 */}
      </div>      
      {/* 전체 목록 부분 + page 컨트롤추가 끝 */}
                </div>
              </div>
            </div>
             {/* Life 콘텐츠 끝 */}

          </div>
        </div>
        {/* <!-- end of container --> */}
      </section>
      {/* <!-- 문장 끝 --> */}

        {/* <!-- 여행 시작 --> */}
        <section class="section" id="blog">
          {/* <!-- container --> */}
          <div class="container text-center">
            <p class="section-subtitle">Where I went?</p>
            <h6 class="section-title mb-6">Trip</h6>
            {/* <!-- 여행박스1 시작 --> */}
            <div class="blog-card">
              <div class="blog-card-header">
                <img
                  src={require("../assets/imgs/down/trip1.jpg")}
                  class="blog-card-img"
                  alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                />
              </div>
              <div class="blog-card-body">
                <h5 class="blog-card-title">Hokkaido</h5>

                <p class="blog-card-caption">
                  <a href="#">2018.12.22</a>
               
                </p>
                <p>
                겨울은 길고 길지만 눈이 있어 견디는 설국
                </p>
                <p> 비에이의 설경</p>              

                <a href="#" class="blog-card-link">
                  Read more <i class="ti-angle-double-right"></i>
                </a>
              </div>
            </div>
            {/* <!--여행박스1 끝 --> */}

            {/* <!-- 여행박스2 시작 --> */}
            <div class="blog-card">
              <div class="blog-card-header">
                <img
                  src={require("../assets/imgs/down/trip2.jpg")}
                  class="blog-card-img"
                  alt="Download free bootstrap 4 landing page, free boootstrap 4 templates, Download free bootstrap 4.1 landing page, free boootstrap 4.1.1 templates, meyawo Landing page"
                />
              </div>
              <div class="blog-card-body">
                <h5 class="blog-card-title">Okinawa</h5>

                <p class="blog-card-caption">
                  <a href="#">2019.03.27</a>                
                </p>

                <p>
                자연경관은 물론 독특한 역사 문화와 섬나라 특유의 넉넉한 인심까지 고스란히 담긴 곳
                </p>
                <p>츄라오미 수족관</p>

                <a href="#" class="blog-card-link">
                  Read more <i class="ti-angle-double-right"></i>
                </a>
              </div>
            </div>
            {/* <!-- 여행박스2 끝 --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- 여행 끝 --> */}

        {/* <!-- contact section --> */}
        <section class="section" id="contact">
          <div class="container text-center">
            <p class="section-subtitle">How can you communicate?</p>
            <h6 class="section-title mb-5">Contact Me</h6>
            {/* <!-- contact form --> */}
            <form action="" class="contact-form col-md-10 col-lg-8 m-auto">
              <div class="form-row">
                <div class="form-group col-sm-6">
                  <input
                    type="text"
                    size="50"
                    class="form-control"
                    placeholder="Your Name"
                    required
                  />
                </div>
                <div class="form-group col-sm-6">
                  <input
                    type="email"
                    class="form-control"
                    placeholder="Enter Email"
                    requried
                  />
                </div>
                <div class="form-group col-sm-12">
                  <textarea
                    name="comment"
                    id="comment"
                    rows="6"
                    class="form-control"
                    placeholder="Write Something"
                  ></textarea>
                </div>
                <div class="form-group col-sm-12 mt-3">
                  <input
                    type="submit"
                    value="Send Message"
                    class="btn btn-outline-primary rounded"
                  />
                </div>
              </div>
            </form>
            {/* <!-- end of contact form --> */}
          </div>
          {/* <!-- end of container --> */}
        </section>
        {/* <!-- end of contact section --> */}

        {/* <!-- footer --> */}
        <div class="container">
          <footer class="footer">
            <p class="mb-0">
              Copyright
              <script>
                document.write(new Date().getFullYear())
              </script> &copy; <a href="http://www.devcrud.com">DevCRUD</a>{" "}
              Distribution <a href="https://themewagon.com">ThemeWagon</a>
            </p>
            <div class="social-links text-right m-auto ml-sm-auto">
            <a class="logo" href="#">
                <i class="ti-facebook">P</i>
              </a>
              <a class="logo" href="#">
                <i class="ti-twitter-alt">A</i>
              </a>
              <a class="logo" href="#">
                <i class="ti-google">G</i>
              </a>
              <a class="logo" href="#">
                <i class="ti-pinterest-alt">E</i>
              </a>
              <a class="logo" href="#">
                <i class="ti-instagram">U</i>
              </a>
              <a class="logo" href="#">
                <i class="ti-rss">P</i>
              </a>
            </div>
          </footer>
        </div>
        {/* <!-- end of page footer --> */}
      </div>
    </div>
  );
}

export default Home;
