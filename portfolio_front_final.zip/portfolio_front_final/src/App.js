import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css'

// 메뉴 라이브러리
import {Routes, Route} from "react-router-dom";

import Home from './pages/Home';

function App() {
  return (
    
    <div className="App">
      
      {/* 전체화면을 바뀌는 부분으로 구성 */}
      {/* Routes 태그 : 바뀌는 페이지 */}
      <Routes>
        {/* 1 페이지 */}
        {/* "/" 클릭하면(첫페이지가 뜨면) Home 컴포넌트 동작 */}
        <Route path="/" element={<Home />} />
      </Routes>
    </div>
  );
}

export default App;
