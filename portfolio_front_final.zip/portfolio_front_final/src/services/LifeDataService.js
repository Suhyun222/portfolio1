// 비동기 통신 라이브러리 import
import http from "../utils/http-common";

// 1)Life 전체 조회 함수, 2)문장 like 검색(쿼리스트링)
// page : 현재페이지, size : 페이지 당 개수
const getLifeAll = (lifeSentence, page, size) => {
  return http.get(`/life?lifeSentence=${lifeSentence}&page=${page}&size=${size}`);
};

// 다른 페이지에서 사용할 수 있게 export 함
const LifeDataService = {
  getLifeAll  
}

export default LifeDataService;
